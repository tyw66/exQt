#ifndef AREADIALOG_H
#define AREADIALOG_H

#include <QDialog>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QComboBox>
#include <QLineEdit>
#include <QPushButton>
#include <QString>
#include <QStackedWidget>

#define PI 3.1415926

/**
 * @brief 计算面积和周长
 */
class AreaDialog : public QDialog
{
    Q_OBJECT

public:
    AreaDialog(QWidget *parent = NULL);
    ~AreaDialog();

private:
    /**
     * @brief 初始化UI
     */
    void initUI();

private slots:
    /**
     * @brief 形状下拉组合框变化响应
     * @param index 项序号
     */
    void onShapeTypeChanged(int index);    
    /**
     * @brief 计算按钮响应
     */
    void onCalculate();

private:
    ///形状下拉组合框
    QComboBox * m_combox_type;

    ///堆栈窗体
    QStackedWidget* stackWidget;

    ///半径输入框
    QLineEdit* lineEdit_radius;
    ///高度输入框
    QLineEdit* lineEdit_height;
    ///宽度输入框
    QLineEdit* lineEdit_width;

    ///面积输出框
    QLineEdit* lineEdit_area;
    ///周长输出框
    QLineEdit* lineEdit_perimeter;


};
#endif // AREADIALOG_H
