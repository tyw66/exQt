#include "areadialog.h"
AreaDialog::AreaDialog(QWidget *parent)
    : QDialog(parent)
    ,m_combox_type(NULL),stackWidget(NULL),lineEdit_radius(NULL)
    ,lineEdit_height(NULL),lineEdit_width()
{
    initUI();
}

AreaDialog::~AreaDialog()
{
}

void AreaDialog::initUI()
{
    //主布局
    setWindowTitle(tr("Calulate Demo"));
    QGridLayout* mainLayout = new QGridLayout(0);


    QLabel* label_shape = new QLabel(tr("Shape"),this);
    mainLayout->addWidget(label_shape,0,0);

    m_combox_type = new QComboBox(this);
    m_combox_type->addItem(tr("Circle"),"Circle");
    m_combox_type->addItem(tr("Rectangle"),"Rectangle");
    connect(m_combox_type, SIGNAL(currentIndexChanged(int)),
            this,SLOT(onShapeTypeChanged(int)));
    mainLayout->addWidget(m_combox_type,0,1);


    //初始化圆形参数编辑窗体
    QWidget* circleWidget = new QWidget();
    QGridLayout* cicleLayout = new QGridLayout(0);
    QLabel* label_radius = new QLabel(tr("Radius"));
    cicleLayout->addWidget(label_radius,0,0);
    lineEdit_radius = new QLineEdit();
    cicleLayout->addWidget(lineEdit_radius,0,1);
    circleWidget->setLayout(cicleLayout);

    //初始化矩形参数编辑窗体
    QWidget* rectangleWidget = new QWidget();
    QGridLayout *rectLayout = new QGridLayout(0);
    QLabel* label_width = new QLabel(tr("Width"));
    rectLayout->addWidget(label_width,0,0);
    lineEdit_width = new QLineEdit();
    rectLayout->addWidget(lineEdit_width,0,1);
    QLabel* label_height = new QLabel(tr("Height"));
    rectLayout->addWidget(label_height,1,0);
    lineEdit_height = new QLineEdit();
    rectLayout->addWidget(lineEdit_height,1,1);
    rectangleWidget->setLayout(rectLayout);

    //将参数编辑窗体添加到堆栈窗体中
    stackWidget = new QStackedWidget();
    mainLayout->addWidget(stackWidget,1,0,1,2);

    ///<<<<<<<<< 请填写

    stackWidget->addWidget(circleWidget);
    stackWidget->addWidget(rectangleWidget);

    ///请填写 >>>>>>>>>

    //输出的区域
    QLabel* label_out = new QLabel(tr("Output"),this);
    label_out->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(label_out,2,0,1,2);

    QLabel* label_area = new QLabel(tr("Area"),this);
    mainLayout->addWidget(label_area,3,0);
    lineEdit_area = new QLineEdit(this);
    mainLayout->addWidget(lineEdit_area,3,1);

    QLabel* label_perimeter = new QLabel(tr("Perimeter"),this);
    mainLayout->addWidget(label_perimeter,4,0);
    lineEdit_perimeter = new QLineEdit(this);
    mainLayout->addWidget(lineEdit_perimeter,4,1);


    //计算按钮
    QPushButton* button_cal = new QPushButton(tr("Calculate"), this);
    connect(button_cal, SIGNAL(clicked()),
            this,SLOT(onCalculate()));
    mainLayout->addWidget(button_cal,5,0,1,2);

    setLayout(mainLayout);

    //限制输入（进阶）
    lineEdit_area->setReadOnly(true);
    lineEdit_perimeter->setReadOnly(true);

}



void AreaDialog::onShapeTypeChanged(int index)
{
    ///<<<<<<<<< 请填写

    //堆栈窗体切换
    stackWidget->setCurrentIndex(index);

    //清空结果区（进阶）
    lineEdit_area->clear();
    lineEdit_perimeter->clear();

    /// 请填写 >>>>>>>>>
}

void AreaDialog::onCalculate()
{
    ///<<<<<<<<< 请填写

    QString type = m_combox_type->currentData().toString();
    if(type.toLower() == "circle"){
        double radius = lineEdit_radius->text().toDouble();

        double area = radius< 0 ? -1 :PI * radius *radius;
        double perimeter = radius< 0 ? -1 :PI * radius * 2;

        lineEdit_area->setText(QString::number(area));
        lineEdit_perimeter->setText(QString::number(perimeter));

    }else{
        double h = lineEdit_height->text().toDouble();
        double w = lineEdit_width->text().toDouble();

        double area = -1;
        if(h >= 0 || w >= 0){
            area = h * w;
        }

        double perimeter = -1;
        if(h >= 0 || w >= 0){
            perimeter = (h + w) * 2;
        }

        lineEdit_area->setText(QString::number(area));
        lineEdit_perimeter->setText(QString::number(perimeter));

    }

    ///请填写 >>>>>>>>>
}











